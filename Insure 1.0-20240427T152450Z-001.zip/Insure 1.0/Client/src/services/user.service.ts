import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {API} from 'src/environments/environment';
import {User} from 'src/types/user.type';
import {BlockchainService} from './blockchain.service';
import {Result} from "../types/ResultAnalysis";
import {ResultAnalysisService} from "./result-analysis.service";

@Injectable({
  providedIn: 'root',
})
export class UserService {
  _API = API + 'user';

  constructor(private http: HttpClient, private bs: BlockchainService, private ra: ResultAnalysisService) {
  }

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this._API);
  }

  addUser(user: User): Promise<any> {

    return new Promise((resolve, reject) => {
      this.addUserToBC(user)
        .then((r: boolean) => {
          if (r) {
            this.http.post<User>(this._API, user).subscribe((user: User) => {
              resolve(user);
            });
          }
        })
        .catch((e: any) => {
          console.log(e);
          reject(e);
        });
    });
  }

  addUserToBC(user: User): Promise<any> {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then((c) => {
        this.bs.getCurrentAcount().then((a) => {
          console.log(a, user.pID, user.insID);
          c.methods
            .addUser(user.pID, 'password')
            .send({from: a})
            .on('confirmation', (c: any, r: any) => {
              const gasUsed = r.gasUsed;
              const totalCost = (gasUsed * 20) / 1000000000 + " ETH";

              const endTime = new Date().getTime();
              let DATA: Result = {
                fnName: "addUser()",
                timeTaken: (endTime - startTime) / 1000 + " s",
                userID: a + " : (user)",
                time: "" + startTime,
                gasUsed: gasUsed,
                totalCost: totalCost,
              };
              this.ra.addResult(DATA).subscribe(() => {
              });
              resolve(true);
            })
            .on('error', (err: any) => {
              console.log(err);
              reject(false);
            });
        });
      });
    });
  }

  getCount(): Observable<{ count: number }> {
    return this.http.get<{ count: number }>(this._API + '/getCount')
  }
}

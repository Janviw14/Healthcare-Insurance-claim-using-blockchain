import {TestBed} from '@angular/core/testing';

import {ResultAnalysisService} from './result-analysis.service';

describe('ResultAnalysisService', () => {
  let service: ResultAnalysisService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ResultAnalysisService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

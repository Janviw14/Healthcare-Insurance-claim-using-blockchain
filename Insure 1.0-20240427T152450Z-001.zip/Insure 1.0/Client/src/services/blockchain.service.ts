import {Injectable} from '@angular/core';
import {IPFSHTTPClient} from 'ipfs-http-client';
import Web3 from 'web3';
import {IpfsService} from './ipfs.service';

const Contract = require('../../build/contracts/Insure.json');

declare let window: any;

@Injectable({
  providedIn: 'root',
})
export class BlockchainService {
  web3!: Web3;
  ipfs!: IPFSHTTPClient;
  account!: string;

  address!: string;
  contract: any;
  netId: any;
  netWorkData: any;
  abi: any;

  constructor(ipfsService: IpfsService) {
    this.ipfs = ipfsService.getIPFS();
    this.getWeb3Provider().then((web3: Web3) => {
      web3.eth.net
        .getId()
        .then((id: number) => {
          this.netId = id;
          this.abi = Contract.abi;
          this.netWorkData = Contract.networks[this.netId];
          if (this.netWorkData) {
            this.address = this.netWorkData.address;
            this.contract = new web3.eth.Contract(this.abi, this.address);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    });

    this.getContract()
      .then((c) => {
        // console.log(c)
        this.contract = c;
      })
      .catch((e) => {
        console.log(e);
      });

    window.ethereum.on('accountsChanged', (acc: any) => {
      console.log(acc);
      window.location.reload();
    });
  }

  getContract(): Promise<any> {
    let reTry = false;
    return new Promise((resolve, reject) => {
      let check = setInterval(() => {
        if (this.contract != undefined) {
          resolve(this.contract);
          clearInterval(check);
        } else {
          if (!reTry) {
            this.getContract();
            reTry = true;
          } else {
            reject(null);
          }
        }
      }, 1000);
    });
  }

  isAdmin(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.getContract().then((c) => {
        this.getCurrentAcount().then((a) => {
          c.methods
            .isAdmin(a)
            .call()
            .then((r: any) => {
              resolve(r);
            })
            .catch((e: any) => {
              reject(e);
            });
        });
      });
    });
  }

  async getWeb3Provider(): Promise<Web3> {
    if (window.ethereum) {
      window.web3 = new Web3(window.ethereum);
      window.ethereum.enable();
      // console.log(window.web3);

      this.web3 = window.web3;
      this.account = await this.web3.eth.getAccounts().then((acc: string[]) => {
        // console.log(acc);
        return acc[0];
      });
      return window.web3;
    } else if (window.web3) {
      window.web3 = new Web3(window.web3.currentProvider);
      return window.web3;
    } else {
      return window.web3;
    }
  }

  getCurrentAcount(): Promise<string> {
    return new Promise((resolve, reject) => {
      if (this.web3) {
        this.web3.eth.getAccounts().then((acc: string[]) => {
          console.log(acc[0]);
          resolve(acc[0]);
        });
      } else {
        reject(null);
      }
    });
  }
}

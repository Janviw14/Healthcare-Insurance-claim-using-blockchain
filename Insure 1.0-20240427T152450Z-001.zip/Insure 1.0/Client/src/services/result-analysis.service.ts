import {HttpClient} from "@angular/common/http";
import {Injectable} from "@angular/core";
import {Result} from "src/types/ResultAnalysis";

interface RESULT {
  fnName: string;
  timeTaken: string;
  userID: string;
  time: string;
}
@Injectable({
  providedIn: "root",
})
export class ResultAnalysisService {
  API = "http://localhost:4201/api/";

  constructor(private http: HttpClient) {}

  addResult(data: {}) {
    return this.http.post(this.API + "result_analysis/", data);
  }

  getResults() {
    return this.http.get<Result[]>(
      this.API + "result_analysis/"
    );
  }

  getFunctionCallCount() {
    return this.http.get(this.API + "getFunctionCallCount/");
  }

  getCostOfFunctions() {
    return this.http.get(this.API + "getCostOfFunctions/");
  }

  getTimeTakenByFunctions() {
    return this.http.get(this.API + "getTimeTakenByFunctions/");
  }

  getGasUsedByFunctions() {
    return this.http.get(this.API + "getGasUsedByFunctions/");
  }
}

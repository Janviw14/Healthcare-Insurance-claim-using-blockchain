import {Injectable} from '@angular/core';
import {create, IPFSHTTPClient} from 'ipfs-http-client';

@Injectable({
  providedIn: 'root',
})
export class IpfsService {
  ipfs!: IPFSHTTPClient;
  constructor() {
    this.ipfs = create({ url: "http://127.0.0.1:5001/api/v0" });
  }

  getIPFS() {
    return this.ipfs;
  }
}

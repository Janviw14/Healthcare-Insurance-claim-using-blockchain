import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {AdminRoutingModule} from './admin-routing.module';
import {DashboardComponent} from './dashboard/dashboard.component';
import {SidenavComponent} from './sidenav/sidenav.component';
import {HomeComponent} from './home/home.component';
import {UserComponent} from './user/user.component';
import {InsuranceComponent} from './insurance/insurance.component';
import {ClaimsComponent} from './claims/claims.component';
import {UtilsModule} from 'src/utils/utils.module';
import {ResultAnalysisComponent} from "./result-analysis/result-analysis.component";
import {ResultChartsComponent} from "./result-charts/result-charts.component";
import {MatTableModule} from "@angular/material/table";
import {MatPaginatorModule} from "@angular/material/paginator";
import {NgChartsModule} from "ng2-charts";


@NgModule({
  declarations: [
    DashboardComponent,
    SidenavComponent,
    HomeComponent,
    UserComponent,
    InsuranceComponent,
    ClaimsComponent, ResultAnalysisComponent, ResultChartsComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule, HttpClientModule, FormsModule, UtilsModule, MatTableModule,
    MatPaginatorModule, NgChartsModule
  ]
})
export class AdminModule {
}

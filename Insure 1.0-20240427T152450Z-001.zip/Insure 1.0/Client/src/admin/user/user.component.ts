import {Component, OnInit} from '@angular/core';
import {UserService} from 'src/services/user.service';
import {User} from 'src/types/user.type';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.sass'],
})
export class UserComponent implements OnInit {
  Users: User[] = [];

  constructor(private us: UserService) {}

  ngOnInit(): void {
    this.getUsers();
  }

  getUsers() {
    this.us.getUsers().subscribe((data) => {
      this.Users = data;
    });
  }
}

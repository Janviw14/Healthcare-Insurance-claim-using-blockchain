import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {API} from 'src/environments/environment';
import {BlockchainService} from 'src/services/blockchain.service';
import {Insurance} from 'src/types/insurance.type';
import {ResultAnalysisService} from "../../services/result-analysis.service";
import {Result} from "../../types/ResultAnalysis";

@Injectable({
  providedIn: 'root',
})
export class InsuranceService {
  _API = API + 'agency';

  constructor(private http: HttpClient, private bs: BlockchainService, private ra: ResultAnalysisService) {
  }

  getAgencies(): Observable<Insurance[]> {
    return this.http.get<Insurance[]>(this._API);
  }

  addAgency(data: Insurance): Promise<any> {

    return new Promise((resolve, reject) => {
      this.addAgencyToBC(data).then((r) => {
        if (r) {
          this.http
            .post<Insurance>(this._API, data)
            .subscribe((r: Insurance) => {
              resolve(r);
            });
        }
      });
    });
  }

  addAgencyToBC(agent: Insurance): Promise<boolean> {
    // console.log(agent)
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then((c) => {
        // console.log(c)
        this.bs.getCurrentAcount().then((a) => {
          // console.log(a)
          c.methods
            .addAgent(agent.aID)
            .send({from: a})
            .on('confirmation', (c: any, r: any) => {
              // console.log(c, r)
              const gasUsed = r.gasUsed;
              const totalCost = (gasUsed * 20) / 1000000000 + " ETH";
              // console.log(r);
              const endTime = new Date().getTime();
              let DATA: Result = {
                fnName: "addAgency()",
                timeTaken: (endTime - startTime) / 1000 + " s",
                userID: a + " : (Admin)",
                time: "" + startTime,
                gasUsed: gasUsed,
                totalCost: totalCost,
              };
              this.ra.addResult(DATA).subscribe(() => {
              });
              resolve(true);
            })
            .on('error', (err: any) => {
              console.log(err);
              reject(false);
            });
        });
      });
    });
  }

  getCount(): Observable<{ count: number }> {
    return this.http.get<{ count: number }>(this._API + '/getCount')
  }
}

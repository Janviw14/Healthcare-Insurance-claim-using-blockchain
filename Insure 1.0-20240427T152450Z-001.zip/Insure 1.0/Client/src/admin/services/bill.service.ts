import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {IPFSHTTPClient} from 'ipfs-http-client/dist/src/types';
import {Observable} from 'rxjs';
import {API} from 'src/environments/environment';
import {BlockchainService} from 'src/services/blockchain.service';
import {IpfsService} from 'src/services/ipfs.service';

import {Bill} from 'src/types/bill.type';
import {Result} from "../../types/ResultAnalysis";
import {ResultAnalysisService} from "../../services/result-analysis.service";

@Injectable({
  providedIn: 'root',
})
export class BillService {
  _API = API + 'bill';
  ipfs: IPFSHTTPClient;

  adminId: string = ''

  constructor(private http: HttpClient, private bs: BlockchainService, _ipfs: IpfsService, private ra: ResultAnalysisService) {
    // this.getAllBillsFromBC();
    this.ipfs = _ipfs.getIPFS()

    bs.getCurrentAcount().then(a => {
      this.adminId = a
    })

  }

  generateReceiptNumber(): Observable<string> {
    return this.http.get<string>(this._API + '/generateReNum');
  }

  getAllBills(): Observable<Bill[]> {
    return this.http.get<Bill[]>(this._API);
  }

  addBill(bill: Bill): Promise<any> {
    let amount = bill.amount;
    return new Promise((resolve, reject) => {
      this.http.post<Bill>(this._API, bill).subscribe((r: Bill) => {
        this.addBillToBC(r, amount)
          .then((r) => {
            if (r) {
              resolve(bill);
            }
          })
          .catch((err: any) => {
            reject(err);
          });
      });
    });
  }

  addBillToBC(bill: Bill, amount: string | undefined): Promise<boolean> {
    return new Promise((resolve, reject) => {
      console.log(bill);
      const startTime = new Date().getTime();
      this.bs.getContract().then((c) => {
        this.bs.getCurrentAcount().then((a) => {
          c.methods
            .addBill(bill.id, bill.patient?.pID, amount, 'Bill Generated')
            .send({from: a})
            .on('confirmation', (c: any, r: any) => {
              console.log(r);
              const gasUsed = r.gasUsed;
              const totalCost = (gasUsed * 20) / 1000000000 + " ETH";
              const endTime = new Date().getTime();
              let DATA: Result = {
                fnName: "addBill()",
                timeTaken: (endTime - startTime) / 1000 + " s",
                userID: this.adminId + " : (Admin)",
                time: "" + startTime,
                gasUsed: gasUsed,
                totalCost: totalCost,
              };
              this.ra.addResult(DATA).subscribe(() => {
              });
              resolve(true);
            })
            .on('error', (err: any) => {
              console.log(err);
              reject(false);
            });
        });
      });
    });
  }

  getAllBillsFromBC(): Promise<any> {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then((c) => {
        c.methods
          .getAllBills()
          .call()
          .then((r: any) => {
            console.log(r);
            const endTime = new Date().getTime();
            let DATA: Result = {
              fnName: "getAllBills()",
              timeTaken: (endTime - startTime) / 1000 + " s",
              userID: this.adminId + " : (Admin)",
              time: "" + startTime,
              gasUsed: "" + 0,
              totalCost: "0 ETH",
            };
            this.ra.addResult(DATA).subscribe(() => {
            });
            resolve(r);
          })
          .catch((err: any) => {
            console.log(err);
            reject(err);
          });
      });
    });
  }

  uploadMR(bill: Bill, files: any): Promise<boolean> {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then(c => {
        this.bs.getCurrentAcount().then(a => {
          this.addRecords(files).then((hash: any) => {
            console.log(bill.bID, bill.cID, bill.patient?.pID, hash);
            c.methods
              .addMedicalRecords(bill.bID, bill.cID, bill.patient?.pID, hash)
              .send({from: a})
              .on('confirmation', (c: any, r: any) => {
                console.log(r);
                const gasUsed = r.gasUsed;
                const totalCost = (gasUsed * 20) / 1000000000 + " ETH";
                const endTime = new Date().getTime();
                let DATA: Result = {
                  fnName: "addMedicalRecords()",
                  timeTaken: (endTime - startTime) / 1000 + " s",
                  userID: this.adminId + " : (Admin)",
                  time: "" + startTime,
                  gasUsed: gasUsed,
                  totalCost: totalCost,
                };
                this.ra.addResult(DATA).subscribe(() => {
                });
                resolve(r)
              }).on('error', (er: any) => {
              console.log(er);
              reject(er)
            })
          })

        })

      })

    })
  }

  async addRecords(data: any) {
    let IPFS_HASHES = []
    for await (const r of this.ipfs.addAll(data)) {
      console.log(r);
      IPFS_HASHES.push(r.path)
    }

    return IPFS_HASHES

  }
}

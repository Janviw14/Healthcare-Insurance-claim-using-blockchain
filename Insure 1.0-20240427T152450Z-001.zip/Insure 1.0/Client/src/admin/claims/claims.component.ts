import {AfterViewInit, Component, ElementRef, OnInit, ViewChild,} from '@angular/core';
import {UserService} from 'src/services/user.service';
import {Bill, BillStatus} from 'src/types/bill.type';
import {User} from 'src/types/user.type';
import {BillService} from '../services/bill.service';

@Component({
  selector: 'app-claims',
  templateUrl: './claims.component.html',
  styleUrls: ['./claims.component.sass'],
})
export class ClaimsComponent implements OnInit, AfterViewInit {
  @ViewChild('addBill') ab!: ElementRef;
  @ViewChild('closeModal') cm!: ElementRef;
  @ViewChild('uploadModal') um!: ElementRef

  Bills: Bill[] = [];
  Patient: User = {
    pID: '',
    fName: '',
    lName: '',
    city: '',
    state: '',
    phone: null,
    email: '',
    dob: null,
    sex: null,
  };

  Users: User[] = [];
  bill: Bill = {
    amount: '',
    patient: null,
    rNum: '',
    date: null,
  };
  Status = BillStatus;

  selectedBill!: Bill
  selectedFiles: FileList | null = null

  prgShow: boolean = false
  prgMsg: string = 'Generating Bill...'
  prgSuccess: boolean = false
  prgWarning: boolean = false
  prgBtnText: string = 'DONE'

  constructor(private us: UserService, private bs: BillService) { }

  ngOnInit(): void {
    this.getAllBills();
    this.getUsers();
  }

  ngAfterViewInit(): void {
    this.ab.nativeElement.addEventListener('click', () => {
      this.generateRecieptNumber();
    });
  }

  getAllBills() {
    this.bs.getAllBills().subscribe((r) => {
      let _Bill: Bill[] = r;
      this.bs.getAllBillsFromBC().then((r: Bill[]) => {
        _Bill.forEach((b: Bill, i: number) => {
          if (b.id === parseInt(r[i]?.bID + '')) {
            _Bill[i].status = r[i].status;
            _Bill[i].amount = r[i].amount;
            _Bill[i].cID = r[i].cID
            _Bill[i].bID = r[i].id
          }
        });
        this.Bills = _Bill;
      });
    });
  }

  getUsers() {
    this.us.getUsers().subscribe((data) => (this.Users = data));
  }

  generateRecieptNumber() {
    this.bs
      .generateReceiptNumber()
      .subscribe((r: any) => (this.bill.rNum = r.data));
  }

  onGenerateBill() {
    this.cm.nativeElement.click();
    this.prgShow = true
    console.log(this.bill);
    this.bs.addBill(this.bill).then((r) => {
      this.prgSuccess = true
      this.prgMsg = "Bill Generated Successfully"
      this.getAllBills();
    }).catch((er: any) => {
      this.prgWarning = true
      this.prgMsg = "Bill Generation Failed.."
    });
  }

  onPatientSelected(ev: Event) {
    // console.log((ev?.target as HTMLInputElement).value);
    let id = (ev?.target as HTMLInputElement).value.split(':')[0];
    this.Users.find((u) => {
      if (u.id == parseInt(id)) {
        this.Patient = u;
        this.bill.patient = u;
      }
    });
  }

  onAmountChange(ev: Event) {
    let amount = (ev?.target as HTMLInputElement).value;
    this.bill.amount = parseFloat(amount) * 0.000008 + ' ETH';
  }

  onUploadDoc(b: Bill) {
    console.log(b);
    this.selectedBill = b
  }

  onFilesChange(ev: Event) {
    this.selectedFiles = (ev.target as HTMLInputElement).files
  }

  uploadMR() {
    this.um.nativeElement.click()
    this.prgShow = true
    this.prgMsg = "Upload in Medical Records to IPFS..."
    this.bs.uploadMR(this.selectedBill, this.selectedFiles).then((r: any) => {
      this.prgSuccess = true
      this.prgMsg = "Medical Records uploaded to IPFS"
      this.getAllBills()
    }).catch((er: any) => {
      this.prgWarning = true
      this.prgMsg = "Medical Records Upload Failed"
    })
  }

  onPrgBtnClick() {
    this.prgShow = false
    this.prgSuccess = false
    this.prgWarning = false
    this.prgMsg = "Loading...."
  }
}

import {Component, OnInit} from '@angular/core';
import {UserService} from 'src/services/user.service';
import {InsuranceService} from '../services/insurance.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.sass']
})
export class HomeComponent implements OnInit {

  userCount: {count:number} = {count:0}
  agentCount: {count:number} = {count:0}

  constructor(private us: UserService, private as: InsuranceService) { }

  ngOnInit(): void {
    this.getCounts()
  }

  getCounts() {
    this.us.getCount().subscribe((r: {count:number}) => {
      this.userCount = r
    })
    this.as.getCount().subscribe((r: {count:number}) => {
      this.agentCount = r
    })
  }

}

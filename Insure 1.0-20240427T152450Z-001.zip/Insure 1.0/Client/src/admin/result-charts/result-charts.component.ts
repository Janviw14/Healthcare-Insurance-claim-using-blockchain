import {Component, OnInit} from "@angular/core";
import {ResultAnalysisService} from "src/services/result-analysis.service";
import {Result} from "src/types/ResultAnalysis";

@Component({
  selector: "app-result-charts",
  templateUrl: "./result-charts.component.html",
  styleUrls: ["./result-charts.component.sass"],
})
export class ResultChartsComponent implements OnInit {
  Results: Result[] = [];
  SevenDays: string[] = [];
  weekChartData: any;
  fnCallData: any;
  fnCostData: any;
  fnTimeData: any;
  fnGasData: any;

  constructor(private rs: ResultAnalysisService) {
  }

  ngOnInit(): void {
    this.getResults();
    this.getFnCallData();
    this.getCostOfFunctions();
    this.getTimeTakenByFunctions();
    this.getGasUsedByFunctions();
  }

  public fnCallOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: true,
        position: "top",
      },
      datalabels: {
        formatter: (value: any, ctx: any) => {
          if (ctx.chart.data.labels) {
            return ctx.chart.data.labels[ctx.dataIndex];
          }
        },
      },
    },
  };

  getResults() {
    this.rs.getResults().subscribe((r: Result[]) => {

      console.log(r);
      this.weekChartData = {
        labels: this.SevenDays.reverse(),
        datasets: [
          {data: [65, 59, 80, 81, 56, 55, 40], label: "Transactions"},
        ],
      };
    });
  }

  getFnCallData() {
    this.rs.getFunctionCallCount().subscribe((r: any) => {
      let counts: any[] = [];
      let fns: any[] = [];
      r.forEach((fn: any) => {
        counts.push(fn.fnName);
        fns.push(fn.count);
      });

      this.fnCallData = {
        labels: counts,
        datasets: [
          {
            data: fns,
          },
        ],
      };
    });
  }

  getCostOfFunctions() {
    this.rs.getCostOfFunctions().subscribe((r: any) => {
      let costs: any[] = [];
      let fns: any[] = [];
      r.forEach((fn: any) => {
        costs.push(parseFloat(fn.cost));
        fns.push(fn.fnName);
      });

      this.fnCostData = {
        labels: fns,
        datasets: [
          {
            data: costs,
            label: "Cost",
          },
        ],
      };
    });
  }

  getTimeTakenByFunctions() {
    this.rs.getTimeTakenByFunctions().subscribe((r: any) => {
      let time: any[] = [];
      let fns: any[] = [];
      r.forEach((fn: any) => {
        time.push(parseFloat(fn.timeTaken));
        fns.push(fn.fnName);
      });

      this.fnTimeData = {
        labels: fns,
        datasets: [
          {
            data: time,
            label: "Time Taken",
            backgroundColor: "rgba(110,159,177,0.9)",
          },
        ],
      };
    });
  }

  getGasUsedByFunctions() {
    this.rs.getGasUsedByFunctions().subscribe((r: any) => {
      let gas: any[] = [];
      let fns: any[] = [];
      r.forEach((fn: any) => {
        gas.push(parseFloat(fn.gasUsed));
        fns.push(fn.fnName);
      });

      this.fnGasData = {
        labels: fns,
        datasets: [
          {
            data: gas,
            label: "Time Taken",
            backgroundColor: "rgba(110,109,177,0.9)",
          },
        ],
      };
    });
  }
}

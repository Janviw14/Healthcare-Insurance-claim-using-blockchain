import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.sass'],
})
export class SidenavComponent implements OnInit {
  @Input() path!: string | undefined;
  @Output() collapseEvent = new EventEmitter();
  collapsed: boolean = false;

  constructor() {
  }

  ngOnInit(): void {
  }

  collapseSideNav() {
    this.collapsed = !this.collapsed
    this.collapseEvent.emit(this.collapsed)
  }

}

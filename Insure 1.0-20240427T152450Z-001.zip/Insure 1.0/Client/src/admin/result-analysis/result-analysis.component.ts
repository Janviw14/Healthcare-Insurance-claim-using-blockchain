import {Component, OnInit, ViewChild} from "@angular/core";
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {MatTableDataSource} from "@angular/material/table";
import {ResultAnalysisService} from "src/services/result-analysis.service";

interface RESULT {
  fnName: string;
  timeTaken: string;
  userID: string;
  time: string;
  gasUsed: string;
  totalCost: string;
}

@Component({
  selector: "app-result-analysis",
  templateUrl: "./result-analysis.component.html",
  styleUrls: ["./result-analysis.component.sass"],
})
export class ResultAnalysisComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  dataSource: MatTableDataSource<RESULT> | any;
  displayedColumns: string[] = [
    "Function Name",
    "User",
    "Start Time",
    "Time Taken",
    "Gas Used",
    "Total Cost",
  ];
  ResultAnalysis: RESULT[] = [];

  constructor(private ra: ResultAnalysisService) {
    this.dataSource = undefined;
  }

  ngOnInit(): void {
    this.getAnalysis();
  }
  getAnalysis() {
    this.ra.getResults().subscribe((r: any) => {
      this.ResultAnalysis = r;
      this.dataSource = new MatTableDataSource(this.ResultAnalysis);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
}

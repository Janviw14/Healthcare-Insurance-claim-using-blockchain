import {AfterViewInit, Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {BlockchainService} from 'src/services/blockchain.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.sass'],
})
export class DashboardComponent implements OnInit, AfterViewInit {
  route: string | undefined = '';
  isAdmin: boolean = false;
  prgMsg: string = "Checking Is Admin..."
  prgSuccess: boolean = false
  prgWarning: boolean = false

  collapsed: boolean = false;

  constructor(
    private bs: BlockchainService,
    private router: Router,
    private ar: ActivatedRoute
  ) {
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    this.bs
      .isAdmin()
      .then((r) => {
        //TODO
        // console.log(r);
        if (r) {
          this.prgSuccess = true
          this.isAdmin = true;
          this.router.navigate(['admin/home']);
          // this.router.navigate(['admin/claims']);
          this.route = this.ar.children[0]?.snapshot.routeConfig?.path;
          this.router.events.subscribe((val) => {
            this.route = this.ar.children[0]?.snapshot.routeConfig?.path;
          });
        } else {
          this.prgWarning = true
          this.prgMsg = "Only Admin Have Access <br/> Connect As ADMIN in Metamask"
          this.isAdmin = false;
        }
      })
      .catch((e) => {
        console.log(e);
      });
  }

  collapseNav(event: boolean) {
    this.collapsed = event
    console.log(this.collapsed)
  }

}

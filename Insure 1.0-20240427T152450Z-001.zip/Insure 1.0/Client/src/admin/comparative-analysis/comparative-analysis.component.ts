import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comparative-analysis',
  templateUrl: './comparative-analysis.component.html',
  styleUrls: ['./comparative-analysis.component.sass']
})
export class ComparativeAnalysisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

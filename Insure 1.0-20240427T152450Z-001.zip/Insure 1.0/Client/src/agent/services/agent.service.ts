import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {API} from 'src/environments/environment';
import {BlockchainService} from 'src/services/blockchain.service';
import {Claim} from 'src/types/claim.type';
import {Insurance} from 'src/types/insurance.type';
import Web3 from 'web3';
import {Result} from "../../types/ResultAnalysis";
import {ResultAnalysisService} from "../../services/result-analysis.service";
import {User} from "../../types/user.type";

@Injectable({
  providedIn: 'root'
})
export class AgentService {

  _AgentAPI = API + 'agency'
  _UserAPI = API + 'user/userById/'
  aID: string = '';

  constructor(private bs: BlockchainService, private http: HttpClient, private ra: ResultAnalysisService) {
  }

  checkIsAgent(): Promise<boolean> {
    return new Promise((reoslve, reject) => {
      this.bs.getContract().then(c => {
        this.bs.getCurrentAcount().then(a => {
          c.methods.isAgent(a).call().then((r: any) => {
            reoslve(r)
          }).catch((er: any) => {
            reject(er)
          })
        })
      })
    })
  }

  getAgency(): Observable<Insurance> {
    return this.http.get<Insurance>(this._AgentAPI + '/getAgencyByaID/' + this.aID)
  }

  getClaims(): Promise<any> {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.getAgentClaims(this.aID).call().then((cm: any) => {
          console.log(cm);
          const endTime = new Date().getTime();
          let DATA: Result = {
            fnName: "getClaims()",
            timeTaken: (endTime - startTime) / 1000 + " s",
            userID: this.aID + " : (Agent)",
            time: "" + startTime,
            gasUsed: "" + 0,
            totalCost: "0 ETH",
          };
          this.ra.addResult(DATA).subscribe(() => {
          });
          resolve(cm)
        }).catch((er: any) => {
          console.log(er);
          reject(er)
        })
      })
    })
  }

  getCurrentAccount(): Promise<string> {
    return new Promise((resolve, reject) => {
      this.bs.getCurrentAcount().then((a: string) => {
        this.aID = a
        resolve(a)
      })
    })

  }

  getUserDetails(id: string): Promise<User> {
    return new Promise<User>((resolve, reject) => {
      this.http.get<User>(this._UserAPI + id).subscribe((u: User) => {
        resolve(u)
      })
    })
  }

  getMedRecords(claim: Claim): Promise<any> {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.getMedicalRecords(claim.id).call({from: this.aID}).then((r: any) => {
          const endTime = new Date().getTime();
          let DATA: Result = {
            fnName: "getMedicalRecords()",
            timeTaken: (endTime - startTime) / 1000 + " s",
            userID: this.aID + " : (Doctor)",
            time: "" + startTime,
            gasUsed: "" + 0,
            totalCost: "0 ETH",
          };
          this.ra.addResult(DATA).subscribe(() => {
          });
          resolve(r)
        }).catch((er: any) => {
          reject(er)
        })
      })
    })
  }

  acceptClaim(claim: Claim): Promise<any> {
    const startTime = new Date().getTime();
    return new Promise((reoslve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.acceptClaim(claim.id, claim.bID)
         .send({from: this.aID})
         .on('confirmation', (a: any, r: any) => {
           const gasUsed = r.gasUsed;
           const totalCost = (gasUsed * 20) / 1000000000 + " ETH";
           const endTime = new Date().getTime();
           let DATA: Result = {
             fnName: "acceptClaim()",
             timeTaken: (endTime - startTime) / 1000 + " s",
             userID: this.aID + " : (Agent)",
             time: "" + startTime,
             gasUsed: gasUsed,
             totalCost: totalCost,
           };
           this.ra.addResult(DATA).subscribe(() => {
           });
           reoslve(true)
         }).on('error', (er: any) => {
          reject(er)
        })
      })
    })
  }

  rejectClaim(claim: Claim): Promise<any> {
    const startTime = new Date().getTime();
    return new Promise((reoslve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.rejectClaim(claim.id, claim.bID)
         .send({from: this.aID})
         .on('confirmation', (a: any, r: any) => {
           console.log(r);
           const gasUsed = r.gasUsed;
           const totalCost = (gasUsed * 20) / 1000000000 + " ETH";
           const endTime = new Date().getTime();
           let DATA: Result = {
             fnName: "rejectClaim()",
             timeTaken: (endTime - startTime) / 1000 + " s",
             userID: this.aID + " : (Agent)",
             time: "" + startTime,
             gasUsed: gasUsed,
             totalCost: totalCost,
           };
           this.ra.addResult(DATA).subscribe(() => {
           });
           reoslve(true)
         }).on('error', (er: any) => {
          reject(er)
        })
      })
    })
  }

  payClaim(claim: Claim): Promise<any> {
    const startTime = new Date().getTime();
    let amount: number = parseFloat(claim.amount.split('ETH')[0])
    return new Promise((resolve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.getAdmin().call().then((a: any) => {
          this.bs.getWeb3Provider().then((web3: Web3) => {
            web3.eth
                .sendTransaction({to: a, from: this.aID, value: web3.utils.toWei(amount + '', 'ether')})
                .then((v: any) => {
                  console.log(v);
                  c.methods.sendPayment(claim.id, claim.bID)
                   .send({from: this.aID})
                   .on('confirmation', (a: any, r: any) => {
                     const gasUsed = r.gasUsed;
                     const totalCost = (gasUsed * 20) / 1000000000 + " ETH";
                     const endTime = new Date().getTime();
                     let DATA: Result = {
                       fnName: "payClaim()",
                       timeTaken: (endTime - startTime) / 1000 + " s",
                       userID: this.aID + " : (Agent)",
                       time: "" + startTime,
                       gasUsed: gasUsed,
                       totalCost: totalCost,
                     };
                     this.ra.addResult(DATA).subscribe(() => {
                     });
                     resolve(r)
                   }).on('error', (er: any) => {
                    reject(er)
                  })
                })
          })
        })
      })
    })
  }
}

import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {AgentRoutingModule} from './agent-routing.module';
import {SidenavComponent} from './sidenav/sidenav.component';
import {HomeComponent} from './home/home.component';
import {UtilsModule} from 'src/utils/utils.module';
import {DashboardComponent} from './dashboard/dashboard.component';


@NgModule({
  declarations: [
    DashboardComponent, SidenavComponent, HomeComponent
  ],
  imports: [
    CommonModule,
    AgentRoutingModule, UtilsModule
  ]
})
export class AgentModule { }

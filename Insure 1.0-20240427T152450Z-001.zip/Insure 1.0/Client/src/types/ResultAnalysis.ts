export interface Result {
  fnName: string;
  timeTaken: string;
  userID: string;
  time: string;
  gasUsed: string;
  totalCost: string;
}

export interface Insurance {
    id?:number;
    aID:string;
    iName:string;
    phone:number | null;
    email:string;
}
import {User} from './user.type';

export interface Bill {
  id?: number;
  bID?: number;
  cID?: number;
  patient: User | null;
  rNum: string;
  date: Date | null;
  amount?: string;
  status?: string;
}

export const BillStatus = [
  "Bill Generated",
  "Claim Submitted \n Awaiting Medical Records from Hospital",
  "Medical Records Submitted \n Awaiting Agency",
  "Claim Accepted", "Claim Rejected", "Bill Payed"

]

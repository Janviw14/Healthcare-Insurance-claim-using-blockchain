export interface Claim {
    id: number;
    bID: string;
    pID: string;
    aID: string;
    status: string;
    amount: string;
}
import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {BlockchainService} from 'src/services/blockchain.service';
import {UserService} from 'src/services/user.service';
import {User} from 'src/types/user.type';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.sass'],
})
export class RegisterComponent implements OnInit {
  @ViewChild('male') mRadio!: ElementRef;
  @ViewChild('female') fRadio!: ElementRef;
  @ViewChild('other') oRadio!: ElementRef;

  User: User = {
    pID: '',
    fName: 'John',
    lName: 'Doe',
    city: 'Montvale',
    state: 'New Jercy',
    phone: 8891468541,
    email: 'tshamil90@gmail.com',
    dob: null,
    sex: null,
  };

  SX = {
    male: 0,
    female: 0,
    other: 0,
  };

  prgShow: boolean = false
  prgMsg: string = 'Adding User To Network'
  prgSuccess: boolean = false
  prgWarning: boolean = false
  prgBtnText: string = 'DONE'

  constructor(private bs: BlockchainService, private us: UserService) { }

  ngOnInit(): void {
    this.bs.getCurrentAcount().then((acc) => {
      this.User.pID = acc;
    });
  }

  onSubmit() {
    this.prgShow = true
    console.log(this.User);
    this.us.addUser(this.User).then((r: any) => {
      console.log(r);
      this.prgShow = false
      this.prgSuccess = true
      this.prgMsg = "Registration Completed"
      this.User = {
        pID: '',
        fName: '',
        lName: '',
        city: '',
        state: '',
        phone: null,
        email: '',
        dob: null,
        sex: null,
      }
    }).catch((er: any) => {
      this.prgWarning = true
      this.prgMsg = "Registration Failed.."
    });
  }

  onXchange() {
    if (this.SX.male) {
      this.User.sex = 1;
      this.fRadio.nativeElement.disabled = true;
      this.oRadio.nativeElement.disabled = true;
    } else if (this.SX.female) {
      this.User.sex = 2;
      this.mRadio.nativeElement.disabled = true;
      this.oRadio.nativeElement.disabled = true;
    } else if (this.SX.other) {
      this.User.sex = 3;
      this.fRadio.nativeElement.disabled = true;
      this.mRadio.nativeElement.disabled = true;
    } else {
      this.mRadio.nativeElement.disabled = false;
      this.fRadio.nativeElement.disabled = false;
      this.oRadio.nativeElement.disabled = false;
    }
  }

  onPrgBtnClick() {
    this.prgShow = false
    this.prgSuccess = false
    this.prgWarning = false
    this.prgMsg = "Loading...."
  }
}

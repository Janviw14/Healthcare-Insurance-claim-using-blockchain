import {AfterViewInit, Component, OnInit} from '@angular/core';
import {BlockchainService} from 'src/services/blockchain.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass'],
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'client';
  account!: string;

  isConnected: boolean = false;

  prgSuccess: boolean = false
  prgWarning: boolean = false
  prgMsg: string = 'Connecting To Blockchain'
  prgBtnTxt: string = "Retry"

  constructor(private bs: BlockchainService) {

  }

  ngOnInit(): void {
    this.bs
      .getCurrentAcount()
      .then((acc) => {
        this.account = acc;
      })
      .catch((err) => { });
  }

  ngAfterViewInit(): void {
    this.bs
      .getContract()
      .then((c) => {
        console.log('Connected');
        this.isConnected = true;
        this.prgSuccess = true
        this.prgMsg = " Connected To Blockchain"
      })
      .catch((err) => {
        console.log(err);
        this.prgWarning = true
        this.prgMsg = "Please Open Ganache and Connect to Metamask"
        this.isConnected = false;
      });
  }

  onRetry(){
    //FIXME
  }
}

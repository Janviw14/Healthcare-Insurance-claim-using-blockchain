import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {UserRoutingModule} from './user-routing.module';
import {DashboardComponent} from './dashboard/dashboard.component';
import {SidenavComponent} from './sidenav/sidenav.component';
import {HomeComponent} from './home/home.component';
import {UtilsModule} from 'src/utils/utils.module';


@NgModule({
  declarations: [
    DashboardComponent,
    SidenavComponent,
    HomeComponent
  ],
  imports: [
    CommonModule,
    UserRoutingModule,UtilsModule
  ]
})
export class UserModule { }

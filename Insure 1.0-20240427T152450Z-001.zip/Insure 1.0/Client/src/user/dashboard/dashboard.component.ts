import {AfterViewInit, Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {UserService} from '../services/user.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.sass'],
})
export class DashboardComponent implements OnInit, AfterViewInit {
  route: string | undefined = '';
  isUser: boolean = false;

  prgShow: boolean = false
  prgMsg: string = 'Checking is User'
  prgSuccess: boolean = false
  prgWarning: boolean = false
  prgBtnText: string = 'Retry'


  constructor(
    private us: UserService,
    private ar: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void { }

  ngAfterViewInit(): void {
    this.checkIsUser()
  }

  checkIsUser() {
    this.prgWarning = false
    this.prgSuccess = false
    this.prgMsg = "Checking is User"
    this.us
      .checkIsUser()
      .then((r) => {
        console.log(r);

        if (r) {
          this.isUser = true;
          this.router.navigate(['user/home'])
          this.route = this.ar.children[0]?.snapshot.routeConfig?.path;
          this.router.events.subscribe((val) => {
            this.route = this.ar.children[0]?.snapshot.routeConfig?.path;
          });
        }
        else {
          this.prgMsg = "Only Patients have Access to this Page <br/> Connect as a User in Metamask"
          this.prgWarning = true
        }
      })
      .catch((e) => {
        this.isUser = false;
        this.prgWarning = true
        this.prgMsg = "Only Patients have Access to this Page <br/> Connect as a User in Metamask"
      });
  }

  onPrgBtnClick() {
    this.checkIsUser()
  }

}

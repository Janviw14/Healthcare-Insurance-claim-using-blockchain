import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {API} from 'src/environments/environment';
import {BlockchainService} from 'src/services/blockchain.service';
import {Bill} from 'src/types/bill.type';
import {Insurance} from 'src/types/insurance.type';
import {User} from 'src/types/user.type';
import Web3 from 'web3';
import {Result} from "../../types/ResultAnalysis";
import {ResultAnalysisService} from "../../services/result-analysis.service";

@Injectable({
  providedIn: 'root',
})
export class UserService {
  _BillAPI = API + 'bill';
  _UserAPI = API + 'user'
  _AgencyAPI = API + 'agency'
  userID: string | null = null;

  constructor(private bs: BlockchainService, private http: HttpClient, private ra: ResultAnalysisService) {

  }

  getUser(): Observable<User> {
    return this.http.get<User>(this._UserAPI + "/userById/" + this.userID)
  }

  checkIsUser(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.bs.getContract().then((c) => {
        this.bs.getCurrentAcount().then((a) => {
          c.methods
            .isUser(a)
            .call()
            .then((r: any) => {
              resolve(r);
            })
            .catch((er: any) => {
              console.log(er);
              reject(er);
            });
        });
      });
    });
  }

  async getConnectedAccount() {
    await this.bs.getCurrentAcount().then(a => {
      this.userID = a
    })
  }

  getBills(): Observable<Bill[]> {
    return this.http.get<Bill[]>(this._BillAPI + '/getBillsByUser/' + this.userID);
  }

  getBillsFromBC(): Promise<Bill[]> {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.getBills(this.userID).call().then((r: Bill[]) => {
          const endTime = new Date().getTime();
          let DATA: Result = {
            fnName: "getAllBills()",
            timeTaken: (endTime - startTime) / 1000 + " s",
            userID: this.userID + " : (User)",
            time: "" + startTime,
            gasUsed: "" + 0,
            totalCost: "0 ETH",
          };
          this.ra.addResult(DATA).subscribe(() => {
          });
          resolve(r)
        }).catch((err: any) => {
          reject(err)
        })
      })
    })
  }

  getInsuranceAgencies(): Observable<Insurance[]> {
    return this.http.get<Insurance[]>(this._AgencyAPI)
  }

  claimInsurance(b: Bill, i: Insurance): Promise<boolean> {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.claimInsurance(
          b.bID, b.patient?.pID, i.aID, b.amount, 'Claim Submitted \n Awaiting Medical Records from Hospital'
        ).send({from: this.userID}).on('confirmation', (a: any, r: any) => {
          const gasUsed = r.gasUsed;
          const totalCost = (gasUsed * 20) / 1000000000 + " ETH";

          const endTime = new Date().getTime();
          let DATA: Result = {
            fnName: "claimInsurance()",
            timeTaken: (endTime - startTime) / 1000 + " s",
            userID: this.userID + " : (User)",
            time: "" + startTime,
            gasUsed: gasUsed,
            totalCost: totalCost,
          };
          this.ra.addResult(DATA).subscribe(() => {
          });
          resolve(true)
        }).on('error', (err: any) => {
          reject(err)
        })
      })
    })
  }

  payBill(bill: Bill): Promise<any> {
    const startTime = new Date().getTime();
    let amount = parseFloat(bill.amount?.split('ETH')[0] + '')
    let cID = bill.cID || 0
    let uID: any = this.userID
    return new Promise((resolve, reject) => {
      this.bs.getContract().then(c => {
        c.methods.getAdmin().call().then((a: any) => {
          this.bs.getWeb3Provider().then((web3: Web3) => {
            web3.eth
              .sendTransaction({to: a, from: uID, value: web3.utils.toWei(amount + '', 'ether')}).then((v: any) => {
              console.log(v);
              c.methods.sendPayment(cID, bill.bID)
                .send({from: this.userID})
                .on('confirmation', (a: any, r: any) => {
                  const gasUsed = r.gasUsed;
                  const totalCost = (gasUsed * 20) / 1000000000 + " ETH";
                  const endTime = new Date().getTime();
                  let DATA: Result = {
                    fnName: "payBill()",
                    timeTaken: (endTime - startTime) / 1000 + " s",
                    userID: this.userID + " : (User)",
                    time: "" + startTime,
                    gasUsed: gasUsed,
                    totalCost: totalCost,
                  };
                  this.ra.addResult(DATA).subscribe(() => {
                  });
                  resolve(r)
                }).on('error', (er: any) => {
                reject(er)
              })
            })
          })
        })
      })
    })
  }
}

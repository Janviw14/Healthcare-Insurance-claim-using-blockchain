import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Bill, BillStatus} from 'src/types/bill.type';
import {Insurance} from 'src/types/insurance.type';
import {User} from 'src/types/user.type';
import {UserService} from '../services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.sass'],
})
export class HomeComponent implements OnInit {
  @ViewChild('closeModal') cm!: ElementRef
  Bills!: Bill[];
  Agents!: Insurance[];
  User: User | null = null

  BillStatus = BillStatus

  selectedBill!: Bill;
  selectedAgent!: Insurance;

  prgShow: boolean = false
  prgMsg: string = 'Submiting Claim'
  prgSuccess: boolean = false
  prgWarning: boolean = false
  prgBtnText: string = 'DONE'
  constructor(private us: UserService) { }

  ngOnInit(): void {
    this.us.getConnectedAccount().then((a) => {
      this.getBills()
      this.us.getUser().subscribe((u: User) => { this.User = u })
    })
    this.getAgencies()
  }

  getAgencies() {
    this.us.getInsuranceAgencies().subscribe((a: Insurance[]) => {
      this.Agents = a
    })
  }

  getBills() {
    this.us.getBills()
      .subscribe((b: Bill[]) => {
        this.Bills = b;
        this.us.getBillsFromBC().then((r: Bill[]) => {
          console.log(r);

          this.Bills.forEach((b: Bill, i: number) => {
            b.status = r[i].status
            b.amount = r[i].amount
            b.bID = r[i].id
          })
        })
      });
  }

  onClaimInsurance() {
    this.cm.nativeElement.click()
    this.prgShow = true
    this.prgMsg = "Submitting Claim..."
    console.log(this.selectedBill, this.selectedAgent);
    this.us.claimInsurance(this.selectedBill, this.selectedAgent).then(r => {
      this.getBills()
      this.prgSuccess = true
      this.prgMsg = "Claim Submitted. <br>Awaiting Hospital For Medical Records"
    }).catch(er => {
      this.prgWarning = true
      this.prgMsg = "Submiting Claim Failed!"
      console.log(er);
    })
  }

  onAgentSelected(ev: Event) {

    this.Agents.forEach(a => {
      if (a.iName == (ev.target as HTMLInputElement).value) {
        this.selectedAgent = a
      }
    })
  }

  onPrgBtnClick() {
    this.prgShow = false
    this.prgSuccess = false
    this.prgWarning = false
    this.prgMsg = "Loading...."
  }

  payBill(c: Bill) {
    this.prgShow = true
    this.prgMsg = "Paying The Bill"
    this.us.payBill(c).then((r: any) => {
      this.prgSuccess = true
      this.prgMsg = "Bill Payed Successfully..."
      this.getBills()
    }).catch((er: any) => {
      this.prgWarning = true
      this.prgMsg = "Payment Failed..."
    })
  }
}

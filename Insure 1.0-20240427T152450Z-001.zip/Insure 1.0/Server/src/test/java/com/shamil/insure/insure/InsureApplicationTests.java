package com.shamil.insure.insure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsureApplicationTests {

	@Test
	void contextLoads() {
	}

}
